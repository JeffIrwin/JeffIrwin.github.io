
<link rel="shortcut icon" type="image/png" href="favicon.png">

{% include header.md %}

# Posts

Longer-form articles on subjects of tech etc.:
- [Abstract interfaces: swapping functions on the fly (2021 Dec 11)]({{site.url}}/posts/2021-12-11-a)

