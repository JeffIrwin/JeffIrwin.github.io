
<link rel="shortcut icon" type="image/png" href="favicon.png">

<!--</div> ends .full-width that started in _includes/header.html -->

{% include header.md %}

# Jeff Irwin's home page

Highlights of some of my toys include:

- [A Rubik's cube game written in JavaScript](rubik-js/){:target="_blank"}
- [A heat mapping tool for fitness data](https://github.com/JeffIrwin/maph){:target="_blank"}
- [Transcoding the complete COVID-19 genome as an mp3](https://github.com/JeffIrwin/music-of-the-sars){:target="_blank"}

For more, see my [GitHub profile](https://github.com/JeffIrwin){:target="_blank"}

{% include footer.md %}

